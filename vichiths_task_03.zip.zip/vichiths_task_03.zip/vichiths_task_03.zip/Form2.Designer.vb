﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.IconButton1 = New FontAwesome.Sharp.IconButton()
        Me.IconButton2 = New FontAwesome.Sharp.IconButton()
        Me.IconButton3 = New FontAwesome.Sharp.IconButton()
        Me.IconButton4 = New FontAwesome.Sharp.IconButton()
        Me.IconButton5 = New FontAwesome.Sharp.IconButton()
        Me.IconButton6 = New FontAwesome.Sharp.IconButton()
        Me.IconButton7 = New FontAwesome.Sharp.IconButton()
        Me.IconButton8 = New FontAwesome.Sharp.IconButton()
        Me.IconButton9 = New FontAwesome.Sharp.IconButton()
        Me.IconButton10 = New FontAwesome.Sharp.IconButton()
        Me.IconButton11 = New FontAwesome.Sharp.IconButton()
        Me.IconButton12 = New FontAwesome.Sharp.IconButton()
        Me.IconButton13 = New FontAwesome.Sharp.IconButton()
        Me.IconButton14 = New FontAwesome.Sharp.IconButton()
        Me.Panel1.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Black
        Me.Panel1.Controls.Add(Me.IconButton3)
        Me.Panel1.Controls.Add(Me.IconButton2)
        Me.Panel1.Controls.Add(Me.IconButton1)
        Me.Panel1.Controls.Add(Me.Panel3)
        Me.Panel1.Location = New System.Drawing.Point(1, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1067, 70)
        Me.Panel1.TabIndex = 0
        '
        'Panel2
        '
        Me.Panel2.Location = New System.Drawing.Point(172, 178)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(8, 8)
        Me.Panel2.TabIndex = 1
        '
        'Panel3
        '
        Me.Panel3.Location = New System.Drawing.Point(7, 68)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(383, 603)
        Me.Panel3.TabIndex = 0
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.Fuchsia
        Me.Panel4.Controls.Add(Me.IconButton10)
        Me.Panel4.Controls.Add(Me.IconButton9)
        Me.Panel4.Controls.Add(Me.IconButton8)
        Me.Panel4.Controls.Add(Me.IconButton7)
        Me.Panel4.Controls.Add(Me.IconButton6)
        Me.Panel4.Controls.Add(Me.IconButton5)
        Me.Panel4.Controls.Add(Me.IconButton4)
        Me.Panel4.Controls.Add(Me.Panel2)
        Me.Panel4.Location = New System.Drawing.Point(2, 68)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(419, 629)
        Me.Panel4.TabIndex = 2
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.Panel5.Controls.Add(Me.IconButton14)
        Me.Panel5.Controls.Add(Me.IconButton13)
        Me.Panel5.Controls.Add(Me.IconButton12)
        Me.Panel5.Controls.Add(Me.IconButton11)
        Me.Panel5.Location = New System.Drawing.Point(421, 68)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(646, 618)
        Me.Panel5.TabIndex = 3
        '
        'IconButton1
        '
        Me.IconButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.IconButton1.IconChar = FontAwesome.Sharp.IconChar.X
        Me.IconButton1.IconColor = System.Drawing.Color.Red
        Me.IconButton1.IconFont = FontAwesome.Sharp.IconFont.[Auto]
        Me.IconButton1.IconSize = 32
        Me.IconButton1.Location = New System.Drawing.Point(1023, 12)
        Me.IconButton1.Name = "IconButton1"
        Me.IconButton1.Size = New System.Drawing.Size(31, 32)
        Me.IconButton1.TabIndex = 1
        Me.IconButton1.UseVisualStyleBackColor = True
        '
        'IconButton2
        '
        Me.IconButton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.IconButton2.IconChar = FontAwesome.Sharp.IconChar.FloppyDisk
        Me.IconButton2.IconColor = System.Drawing.Color.Red
        Me.IconButton2.IconFont = FontAwesome.Sharp.IconFont.[Auto]
        Me.IconButton2.IconSize = 32
        Me.IconButton2.Location = New System.Drawing.Point(986, 12)
        Me.IconButton2.Name = "IconButton2"
        Me.IconButton2.Size = New System.Drawing.Size(31, 32)
        Me.IconButton2.TabIndex = 2
        Me.IconButton2.UseVisualStyleBackColor = True
        '
        'IconButton3
        '
        Me.IconButton3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.IconButton3.IconChar = FontAwesome.Sharp.IconChar.Minus
        Me.IconButton3.IconColor = System.Drawing.Color.Red
        Me.IconButton3.IconFont = FontAwesome.Sharp.IconFont.[Auto]
        Me.IconButton3.IconSize = 32
        Me.IconButton3.Location = New System.Drawing.Point(949, 12)
        Me.IconButton3.Name = "IconButton3"
        Me.IconButton3.Size = New System.Drawing.Size(31, 32)
        Me.IconButton3.TabIndex = 3
        Me.IconButton3.UseVisualStyleBackColor = True
        '
        'IconButton4
        '
        Me.IconButton4.BackColor = System.Drawing.Color.Fuchsia
        Me.IconButton4.FlatAppearance.BorderColor = System.Drawing.Color.Fuchsia
        Me.IconButton4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.IconButton4.IconChar = FontAwesome.Sharp.IconChar.UserAlt
        Me.IconButton4.IconColor = System.Drawing.Color.Black
        Me.IconButton4.IconFont = FontAwesome.Sharp.IconFont.[Auto]
        Me.IconButton4.IconSize = 140
        Me.IconButton4.Location = New System.Drawing.Point(110, 43)
        Me.IconButton4.Name = "IconButton4"
        Me.IconButton4.Size = New System.Drawing.Size(203, 216)
        Me.IconButton4.TabIndex = 2
        Me.IconButton4.UseVisualStyleBackColor = False
        '
        'IconButton5
        '
        Me.IconButton5.FlatAppearance.BorderColor = System.Drawing.Color.Fuchsia
        Me.IconButton5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.IconButton5.Font = New System.Drawing.Font("Kh Battambang", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.IconButton5.IconChar = FontAwesome.Sharp.IconChar.HomeLg
        Me.IconButton5.IconColor = System.Drawing.Color.Black
        Me.IconButton5.IconFont = FontAwesome.Sharp.IconFont.[Auto]
        Me.IconButton5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.IconButton5.Location = New System.Drawing.Point(28, 252)
        Me.IconButton5.Name = "IconButton5"
        Me.IconButton5.Size = New System.Drawing.Size(351, 74)
        Me.IconButton5.TabIndex = 3
        Me.IconButton5.Text = "ទំព័រដើម"
        Me.IconButton5.UseVisualStyleBackColor = False
        '
        'IconButton6
        '
        Me.IconButton6.FlatAppearance.BorderColor = System.Drawing.Color.Fuchsia
        Me.IconButton6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.IconButton6.Font = New System.Drawing.Font("Kh Battambang", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.IconButton6.IconChar = FontAwesome.Sharp.IconChar.Gears
        Me.IconButton6.IconColor = System.Drawing.Color.Black
        Me.IconButton6.IconFont = FontAwesome.Sharp.IconFont.[Auto]
        Me.IconButton6.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.IconButton6.Location = New System.Drawing.Point(28, 342)
        Me.IconButton6.Name = "IconButton6"
        Me.IconButton6.Size = New System.Drawing.Size(351, 74)
        Me.IconButton6.TabIndex = 4
        Me.IconButton6.Text = "ការកំណត់"
        Me.IconButton6.UseVisualStyleBackColor = False
        '
        'IconButton7
        '
        Me.IconButton7.FlatAppearance.BorderColor = System.Drawing.Color.Fuchsia
        Me.IconButton7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.IconButton7.Font = New System.Drawing.Font("Kh Battambang", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.IconButton7.IconChar = FontAwesome.Sharp.IconChar.RightFromBracket
        Me.IconButton7.IconColor = System.Drawing.Color.Black
        Me.IconButton7.IconFont = FontAwesome.Sharp.IconFont.[Auto]
        Me.IconButton7.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.IconButton7.Location = New System.Drawing.Point(28, 437)
        Me.IconButton7.Name = "IconButton7"
        Me.IconButton7.Size = New System.Drawing.Size(351, 74)
        Me.IconButton7.TabIndex = 5
        Me.IconButton7.Text = "ចាកចេញ"
        Me.IconButton7.UseVisualStyleBackColor = False
        '
        'IconButton8
        '
        Me.IconButton8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.IconButton8.IconChar = FontAwesome.Sharp.IconChar.Facebook
        Me.IconButton8.IconColor = System.Drawing.Color.Black
        Me.IconButton8.IconFont = FontAwesome.Sharp.IconFont.[Auto]
        Me.IconButton8.IconSize = 40
        Me.IconButton8.Location = New System.Drawing.Point(73, 535)
        Me.IconButton8.Name = "IconButton8"
        Me.IconButton8.Size = New System.Drawing.Size(48, 46)
        Me.IconButton8.TabIndex = 6
        Me.IconButton8.UseVisualStyleBackColor = True
        '
        'IconButton9
        '
        Me.IconButton9.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.IconButton9.IconChar = FontAwesome.Sharp.IconChar.Telegram
        Me.IconButton9.IconColor = System.Drawing.Color.Black
        Me.IconButton9.IconFont = FontAwesome.Sharp.IconFont.[Auto]
        Me.IconButton9.IconSize = 40
        Me.IconButton9.Location = New System.Drawing.Point(172, 535)
        Me.IconButton9.Name = "IconButton9"
        Me.IconButton9.Size = New System.Drawing.Size(48, 46)
        Me.IconButton9.TabIndex = 7
        Me.IconButton9.UseVisualStyleBackColor = True
        '
        'IconButton10
        '
        Me.IconButton10.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.IconButton10.IconChar = FontAwesome.Sharp.IconChar.Instagram
        Me.IconButton10.IconColor = System.Drawing.Color.Black
        Me.IconButton10.IconFont = FontAwesome.Sharp.IconFont.[Auto]
        Me.IconButton10.IconSize = 40
        Me.IconButton10.Location = New System.Drawing.Point(265, 535)
        Me.IconButton10.Name = "IconButton10"
        Me.IconButton10.Size = New System.Drawing.Size(48, 46)
        Me.IconButton10.TabIndex = 8
        Me.IconButton10.UseVisualStyleBackColor = True
        '
        'IconButton11
        '
        Me.IconButton11.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.IconButton11.FlatAppearance.BorderColor = System.Drawing.SystemColors.ActiveBorder
        Me.IconButton11.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.IconButton11.IconChar = FontAwesome.Sharp.IconChar.CameraAlt
        Me.IconButton11.IconColor = System.Drawing.Color.Black
        Me.IconButton11.IconFont = FontAwesome.Sharp.IconFont.[Auto]
        Me.IconButton11.IconSize = 140
        Me.IconButton11.Location = New System.Drawing.Point(91, 67)
        Me.IconButton11.Name = "IconButton11"
        Me.IconButton11.Size = New System.Drawing.Size(187, 185)
        Me.IconButton11.TabIndex = 0
        Me.IconButton11.UseVisualStyleBackColor = False
        '
        'IconButton12
        '
        Me.IconButton12.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.IconButton12.FlatAppearance.BorderColor = System.Drawing.SystemColors.ActiveBorder
        Me.IconButton12.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.IconButton12.IconChar = FontAwesome.Sharp.IconChar.Car
        Me.IconButton12.IconColor = System.Drawing.Color.Black
        Me.IconButton12.IconFont = FontAwesome.Sharp.IconFont.[Auto]
        Me.IconButton12.IconSize = 140
        Me.IconButton12.Location = New System.Drawing.Point(419, 74)
        Me.IconButton12.Name = "IconButton12"
        Me.IconButton12.Size = New System.Drawing.Size(187, 185)
        Me.IconButton12.TabIndex = 1
        Me.IconButton12.UseVisualStyleBackColor = False
        '
        'IconButton13
        '
        Me.IconButton13.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.IconButton13.FlatAppearance.BorderColor = System.Drawing.SystemColors.ActiveBorder
        Me.IconButton13.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.IconButton13.IconChar = FontAwesome.Sharp.IconChar.Bicycle
        Me.IconButton13.IconColor = System.Drawing.Color.Black
        Me.IconButton13.IconFont = FontAwesome.Sharp.IconFont.[Auto]
        Me.IconButton13.IconSize = 140
        Me.IconButton13.Location = New System.Drawing.Point(91, 342)
        Me.IconButton13.Name = "IconButton13"
        Me.IconButton13.Size = New System.Drawing.Size(187, 185)
        Me.IconButton13.TabIndex = 2
        Me.IconButton13.TextAlign = System.Drawing.ContentAlignment.BottomRight
        Me.IconButton13.UseVisualStyleBackColor = False
        '
        'IconButton14
        '
        Me.IconButton14.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.IconButton14.FlatAppearance.BorderColor = System.Drawing.SystemColors.ActiveBorder
        Me.IconButton14.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.IconButton14.IconChar = FontAwesome.Sharp.IconChar.BasketballBall
        Me.IconButton14.IconColor = System.Drawing.Color.Black
        Me.IconButton14.IconFont = FontAwesome.Sharp.IconFont.[Auto]
        Me.IconButton14.IconSize = 140
        Me.IconButton14.Location = New System.Drawing.Point(419, 342)
        Me.IconButton14.Name = "IconButton14"
        Me.IconButton14.Size = New System.Drawing.Size(187, 185)
        Me.IconButton14.TabIndex = 3
        Me.IconButton14.UseVisualStyleBackColor = False
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1067, 678)
        Me.Controls.Add(Me.Panel5)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "Form2"
        Me.Text = "Form2"
        Me.Panel1.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.Panel5.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents IconButton2 As FontAwesome.Sharp.IconButton
    Friend WithEvents IconButton1 As FontAwesome.Sharp.IconButton
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Panel5 As Panel
    Friend WithEvents IconButton3 As FontAwesome.Sharp.IconButton
    Friend WithEvents IconButton5 As FontAwesome.Sharp.IconButton
    Friend WithEvents IconButton4 As FontAwesome.Sharp.IconButton
    Friend WithEvents IconButton7 As FontAwesome.Sharp.IconButton
    Friend WithEvents IconButton6 As FontAwesome.Sharp.IconButton
    Friend WithEvents IconButton10 As FontAwesome.Sharp.IconButton
    Friend WithEvents IconButton9 As FontAwesome.Sharp.IconButton
    Friend WithEvents IconButton8 As FontAwesome.Sharp.IconButton
    Friend WithEvents IconButton14 As FontAwesome.Sharp.IconButton
    Friend WithEvents IconButton13 As FontAwesome.Sharp.IconButton
    Friend WithEvents IconButton12 As FontAwesome.Sharp.IconButton
    Friend WithEvents IconButton11 As FontAwesome.Sharp.IconButton
End Class
