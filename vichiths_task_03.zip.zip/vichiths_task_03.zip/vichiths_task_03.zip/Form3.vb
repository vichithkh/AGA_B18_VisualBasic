﻿Public Class Form3
    Private Sub Label1_Click(sender As Object, e As EventArgs) 

    End Sub
End Class