﻿Public Class Form1
    ' Simulated username and password
    Private Const validUsername As String = "admin"
    Private Const validPassword As String = "admin123"

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        ' Get user input
        Dim username As String = txtUsername.Text
        Dim password As String = txtPassword.Text

        ' Check if credentials match
        If username = validUsername AndAlso password = validPassword Then
            MessageBox.Show("Login Successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Else
            MessageBox.Show("Invalid Username or Password!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Private Sub btnLogout_Click(sender As Object, e As EventArgs) Handles btnLogout.Click
        txtUsername.Clear()
        txtPassword.Clear()
        chkRememberMe.Checked = False
        MessageBox.Show("Logged Out!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    Private Sub lblSignUp_Click(sender As Object, e As EventArgs) Handles lblSignUp.Click
        MessageBox.Show("Sign-Up functionality coming soon!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub
End Class
